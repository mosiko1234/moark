from textual.widgets._tabbed_content import TabPane

__all__ = ["TabPane"]
